// Task Manager - script.js
// Day 7: Styling & Responsive Design — core logic unchanged from Day 6,
// only addition is a small task-summary counter to support the refreshed UI.

const STORAGE_KEY = "tasks";

// Grab references to the HTML elements we need
const taskForm = document.getElementById("task-form");
const taskInput = document.getElementById("task-input");
const taskList = document.getElementById("task-list");
const emptyMessage = document.getElementById("empty-message");
const taskSummary = document.getElementById("task-summary");

// Loads tasks from localStorage. Returns an empty array if nothing is saved
// or if the saved data is corrupted/invalid.
function getTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error("Failed to read tasks from localStorage:", error);
    return [];
  }
}

// Saves the given tasks array to localStorage
function saveTasks(tasksToSave) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasksToSave));
  } catch (error) {
    console.error("Failed to save tasks to localStorage:", error);
  }
}

// In-memory copy of tasks, loaded from localStorage on startup
let tasks = getTasks();

// Creates a new task object, adds it to the array, saves, and re-renders
function addTask(text) {
  const newTask = {
    id: Date.now().toString(),
    text: text,
    completed: false,
    createdAt: new Date().toISOString(),
  };
  tasks.push(newTask);
  saveTasks(tasks);
  renderTasks();
}

// Flips a task's completed status by id, saves, and re-renders
function toggleTaskComplete(id) {
  const task = tasks.find((t) => t.id === id);
  if (task) {
    task.completed = !task.completed;
    saveTasks(tasks);
    renderTasks();
  }
}

// Removes a task from the array by id, saves, and re-renders
function deleteTask(id) {
  const li = taskList.querySelector(`li[data-id="${id}"]`);

  // Play a quick fade/slide-out animation before actually removing the task,
  // for a smoother feel. Falls back instantly if the element isn't found.
  if (li) {
    li.classList.add("removing");
    li.addEventListener(
      "transitionend",
      () => {
        tasks = tasks.filter((t) => t.id !== id);
        saveTasks(tasks);
        renderTasks();
      },
      { once: true }
    );
  } else {
    tasks = tasks.filter((t) => t.id !== id);
    saveTasks(tasks);
    renderTasks();
  }
}

// Updates the small "X of Y tasks completed" summary line above the list
function renderSummary() {
  if (!taskSummary) return;

  if (tasks.length === 0) {
    taskSummary.textContent = "";
    taskSummary.style.display = "none";
    return;
  }

  const completedCount = tasks.filter((t) => t.completed).length;
  taskSummary.style.display = "block";
  taskSummary.textContent = `${completedCount} of ${tasks.length} task${
    tasks.length === 1 ? "" : "s"
  } completed`;
}

// Clears the task list in the DOM and rebuilds it from the tasks array
function renderTasks() {
  taskList.innerHTML = "";

  if (tasks.length === 0) {
    emptyMessage.style.display = "block";
    renderSummary();
    return;
  }

  emptyMessage.style.display = "none";

  tasks.forEach((task) => {
    const li = document.createElement("li");
    li.className = "task-item" + (task.completed ? " completed" : "");
    li.dataset.id = task.id;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "task-checkbox";
    checkbox.checked = task.completed;
    checkbox.setAttribute("aria-label", "Mark task complete: " + task.text);
    checkbox.addEventListener("change", () => toggleTaskComplete(task.id));

    const span = document.createElement("span");
    span.className = "task-text";
    span.textContent = task.text;

    const deleteBtn = document.createElement("button");
    deleteBtn.className = "delete-btn";
    deleteBtn.type = "button";
    deleteBtn.textContent = "Delete";
    deleteBtn.setAttribute("aria-label", "Delete task: " + task.text);
    deleteBtn.addEventListener("click", () => deleteTask(task.id));

    li.appendChild(checkbox);
    li.appendChild(span);
    li.appendChild(deleteBtn);
    taskList.appendChild(li);
  });

  renderSummary();
}

// Handle form submission (clicking "Add" or pressing Enter)
taskForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const text = taskInput.value.trim();

  if (text === "") {
    taskInput.classList.add("input-error");
    taskInput.setAttribute("placeholder", "Please type a task first...");
    setTimeout(() => taskInput.classList.remove("input-error"), 600);
    return;
  }

  addTask(text);
  taskInput.value = "";
  taskInput.focus();
});

// Initial render on page load - shows whatever was loaded from localStorage
renderTasks();

console.log("script.js loaded successfully. Day 7: responsive design + polish active.");
