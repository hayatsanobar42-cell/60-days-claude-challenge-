# SETUP.md
## Simple Task Manager — Installation & Setup Guide

### 1. Prerequisites
| Tool | Version Confirmed | Purpose |
|---|---|---|
| Git | 2.55.0.windows.3 | Version control, pushing code to GitHub |
| Visual Studio Code | 1.127.0 (x64) | Code editor |
| A modern browser | Any (Chrome/Edge/Firefox) | Running/testing the app |

No Node.js, npm, or SDKs are required — this project uses plain HTML/CSS/JS with no build tools.

### 2. One-Time Git Identity Setup
```
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```
Verify with:
```
git config --global user.name
git config --global user.email
```

### 3. Getting the Project Locally
If cloning fresh from GitHub:
```
git clone https://github.com/hayatsanobar42-cell/task-manager.git
cd task-manager
```
If continuing local work, project lives at:
```
C:\Users\HP\Documents\task-manager
```

### 4. Opening the Project
```
cd C:\Users\HP\Documents\task-manager
code .
```
This opens the folder in VS Code.

### 5. Running the App
No server or build step needed:
1. In VS Code Explorer, right-click `index.html` → **Reveal in File Explorer**.
2. Double-click `index.html` to open it in your default browser.

(Optional, for auto-reload while developing: install the **Live Server** VS Code extension, then right-click `index.html` → **Open with Live Server**.)

### 6. Verifying Setup
- Browser shows "My Task Manager" header.
- Typing a task and clicking **Add** shows it in the list below.
- No errors appear in the browser console (press `F12` → Console tab to check).

### 7. Git Workflow (day-to-day)
```
git add .
git commit -m "Describe what changed"
git push
```
