# ENVIRONMENT.md
## Simple Task Manager — Environment, Tools & Configuration Reference

### 1. Environment Variables
**None required.** This project has no backend, no API keys, and no secrets — it runs entirely client-side in the browser. There is no `.env` file for this project.

### 2. Installed Tools (confirmed on this machine)
| Tool | Version | Verified Via |
|---|---|---|
| Git | 2.55.0.windows.3 | `git --version` |
| VS Code | 1.127.0 (x64, commit 4fe60c8) | `code --version` |

### 3. Git Global Configuration
| Setting | Value |
|---|---|
| user.name | Sanobar Hayat |
| user.email | hayatsanobar42@gmail.com |

### 4. GitHub Repository
| Field | Value |
|---|---|
| Repo URL | https://github.com/hayatsanobar42-cell/task-manager.git |
| Default branch | main |
| Remote name | origin |

### 5. Project Location
```
C:\Users\HP\Documents\task-manager
```

### 6. Browser Requirements
Any modern browser (Chrome, Edge, Firefox) with JavaScript enabled. No specific version required.

### 7. Configuration Files in This Project
| File | Purpose |
|---|---|
| `.gitignore` | Excludes `.vscode/`, `*.log`, `.DS_Store` from version control |

No other configuration files (no `package.json`, no build config) are needed since there are no dependencies or build tools.
