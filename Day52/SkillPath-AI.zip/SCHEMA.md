# SkillPath AI — Data Schema

Version 1.0 | Day 2 Deliverable

## 1. Scope Note

SkillPath AI v1.0 has **no user accounts, no saved history, and no database** (PRD §6). This document defines the **skill benchmark JSON schema** (static reference data) and the **AI response schema** (runtime, in-memory only, never persisted). This was validated against every FR in the PRD — none require data persistence.

## 2. Skill Benchmark Schema (`data/roles/*.json`)

One file per predefined role.

```json
{
  "roleId": "sde",
  "roleName": "Software Development (SDE)",
  "mustHave": [
    {
      "skill": "Data Structures & Algorithms",
      "why": "Core screening filter for nearly all SDE interviews",
      "sampleProjects": ["LeetCode-style problem portfolio", "Implement a custom data structure library"]
    }
  ],
  "goodToHave": [
    {
      "skill": "System Design Basics",
      "why": "Differentiator for stronger candidates, even at intern level",
      "sampleProjects": ["Design a URL shortener", "Design a rate limiter"]
    }
  ],
  "bonus": [
    {
      "skill": "Open Source Contribution",
      "why": "Signals initiative and real-world collaboration experience",
      "sampleProjects": ["Contribute a fix to a public GitHub repo"]
    }
  ]
}
```

### Field Constraints

| Field | Type | Required | Constraint |
|---|---|---|---|
| roleId | string | Yes | lowercase, kebab-case, unique across files |
| roleName | string | Yes | Human-readable display name |
| mustHave / goodToHave / bonus | array | Yes | At least 1 item in `mustHave`; others may be empty array |
| skill | string | Yes | Non-empty |
| why | string | Yes | 1–2 sentences |
| sampleProjects | array of strings | No | Defaults to `[]` |

### Predefined Roles (fixed set, per PRD §5.2)

`sde.json`, `data-analyst-scientist.json`, `ai-ml-engineer.json`, `web-developer.json`, `core-engineering.json`

## 3. AI Response Schema (runtime, not persisted)

This is the structured JSON the serverless function requests from Claude and passes to the frontend.

```json
{
  "detectedSkills": ["Python", "SQL", "Git"],
  "missingSkills": [
    {
      "skill": "System Design Basics",
      "priority": "must",
      "reason": "Core screening filter for nearly all SDE interviews"
    }
  ],
  "roadmap": [
    {
      "weekRange": "Weeks 1-2",
      "focus": "Data Structures & Algorithms fundamentals",
      "skills": ["Arrays", "Linked Lists", "Recursion"]
    }
  ],
  "resources": [
    {
      "skill": "System Design Basics",
      "type": "course",
      "name": "Grokking the System Design Interview",
      "url": "https://example.com"
    }
  ]
}
```

### Field Constraints

| Field | Type | Required | Constraint |
|---|---|---|---|
| detectedSkills | array of strings | Yes | May be empty if resume has no recognizable skills |
| missingSkills[].priority | string enum | Yes | One of `must`, `good`, `bonus` (maps to 🔴🟡🟢) |
| missingSkills[].reason | string | Yes | Non-empty, plain-language explanation |
| roadmap[].weekRange | string | Yes | Format: `"Weeks N-M"` |
| resources[].type | string enum | Yes | One of `course`, `documentation`, `practice-platform`, `project-idea` |
| resources[].url | string | No | Valid URL if present; omit rather than fabricate if uncertain |

## 4. Custom Role Benchmark (AI-generated, same shape as §2)

For custom roles, Claude is prompted to return the exact same shape as the curated JSON in §2 (`mustHave`/`goodToHave`/`bonus`), so the downstream analysis step is identical regardless of role source. This keeps one single analysis code path for both predefined and custom roles.

## 5. Validation Against PRD User Stories

| PRD Requirement | Schema Support |
|---|---|
| FR-5: compare resume against curated skill map | §2 provides the structured benchmark |
| FR-6: AI-generated benchmark for custom roles | §4 — same shape as §2, so no special-casing downstream |
| FR-8: display detected current skills | `detectedSkills` in §3 |
| FR-9: missing skills grouped by priority | `missingSkills[].priority` enum in §3 |
| FR-10: week-by-week roadmap | `roadmap[]` in §3 |
| FR-11: recommended resources and project ideas | `resources[]` in §3, `sampleProjects` in §2 |

No gaps identified — schema fully covers PRD scope with no unused fields.
