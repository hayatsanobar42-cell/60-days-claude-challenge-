# SkillPath AI — API Design

Version 1.0 | Day 2 Deliverable
No implementation in this document — contracts only.

## Conventions

- Base path: `/api`
- Format: JSON request/response
- Authentication: **None** — no user accounts in v1.0 (PRD §6). Endpoints are public but rate-limited at the platform level (Vercel) to control cost/abuse.
- All errors follow a consistent shape (see §3).

---

## 1. `POST /api/analyze`

Primary and only v1.0 endpoint. Accepts a resume and target role, returns a full skill-gap report.

### Purpose
Runs the complete skill-gap analysis flow (FR-5 through FR-11): loads or generates a benchmark, calls Claude for analysis, returns structured results.

### Authentication
None.

### Request

```json
{
  "resumeText": "string, required, 50-20000 characters",
  "role": "string, required, 2-100 characters",
  "isCustomRole": "boolean, required"
}
```

| Field | Type | Required | Validation |
|---|---|---|---|
| resumeText | string | Yes | Trimmed length between 50 and 20,000 characters |
| role | string | Yes | Trimmed length between 2 and 100 characters |
| isCustomRole | boolean | Yes | If `false`, `role` must match one of the 5 predefined `roleId`s |

### Response — 200 OK

```json
{
  "role": "Software Development (SDE)",
  "detectedSkills": ["Python", "SQL", "Git"],
  "missingSkills": [
    {
      "skill": "System Design Basics",
      "priority": "must",
      "reason": "Core screening filter for nearly all SDE interviews"
    }
  ],
  "roadmap": [
    {
      "weekRange": "Weeks 1-2",
      "focus": "Data Structures & Algorithms fundamentals",
      "skills": ["Arrays", "Linked Lists", "Recursion"]
    }
  ],
  "resources": [
    {
      "skill": "System Design Basics",
      "type": "course",
      "name": "Grokking the System Design Interview",
      "url": "https://example.com"
    }
  ]
}
```

### Error Cases

| Status | Code | Trigger | Response Body Example |
|---|---|---|---|
| 400 | `INVALID_INPUT` | Missing/empty `resumeText` or `role`, or length out of bounds | `{"error":{"code":"INVALID_INPUT","message":"Resume text must be between 50 and 20000 characters."}}` |
| 400 | `INVALID_ROLE` | `isCustomRole:false` but `role` doesn't match a known `roleId` | `{"error":{"code":"INVALID_ROLE","message":"Selected role is not recognized."}}` |
| 429 | `RATE_LIMITED` | Too many requests from client in a short window | `{"error":{"code":"RATE_LIMITED","message":"Too many requests. Please try again shortly."}}` |
| 502 | `AI_UPSTREAM_ERROR` | Claude API call fails, times out, or returns malformed JSON after retry | `{"error":{"code":"AI_UPSTREAM_ERROR","message":"Analysis failed. Please try again."}}` |
| 500 | `INTERNAL_ERROR` | Unhandled server error | `{"error":{"code":"INTERNAL_ERROR","message":"Something went wrong. Please try again."}}` |

Maps directly to FR-13 (friendly error on AI failure) and FR-4 (validation before submission).

---

## 2. `GET /api/roles`

### Purpose
Returns the list of predefined roles for the frontend dropdown, so role names/ids aren't hardcoded twice (frontend + backend).

### Authentication
None.

### Request
No parameters.

### Response — 200 OK

```json
{
  "roles": [
    { "roleId": "sde", "roleName": "Software Development (SDE)" },
    { "roleId": "data-analyst-scientist", "roleName": "Data Analyst / Data Science" },
    { "roleId": "ai-ml-engineer", "roleName": "AI/ML Engineer" },
    { "roleId": "web-developer", "roleName": "Web Developer" },
    { "roleId": "core-engineering", "roleName": "Core Engineering Roles" }
  ]
}
```

### Error Cases

| Status | Code | Trigger |
|---|---|---|
| 500 | `INTERNAL_ERROR` | Skill map files fail to load on server |

---

## 3. Standard Error Shape

All errors across all endpoints use this shape:

```json
{
  "error": {
    "code": "STRING_ENUM",
    "message": "Human-readable, safe-to-display message"
  }
}
```

Raw stack traces, provider error details, or internal identifiers are never included in client-facing error responses.

---

## 4. Endpoints Explicitly Not Built (v1.0)

Per PRD §6, no endpoints exist for: authentication, saved history retrieval, file upload/parsing, or PDF export. These are not stubbed — they simply don't exist in v1.0.
