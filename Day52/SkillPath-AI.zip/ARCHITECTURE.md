# SkillPath AI — Architecture

Version 1.0 | Day 2 Deliverable

## 1. Tech Stack & Rationale

| Layer | Choice | Why |
|---|---|---|
| Frontend | React (Vite) | Fast dev loop, component reuse for dashboard cards, huge free ecosystem |
| Backend | Node.js serverless functions (Vercel Functions) | Zero server management, keeps API key server-side, deploys with frontend in one project |
| AI | Anthropic Claude API | Strong structured-output / instruction-following for JSON skill-gap generation |
| Data | Static curated JSON files in repo (no DB) | v1.0 has no accounts or persistence (PRD §6) — a database would add complexity with no user-facing benefit |
| Hosting | Vercel (free tier) | One-command deploy, free SSL, handles frontend + functions together |
| Auth | None | Explicitly out of scope (PRD §6) |
| Version Control | Git + GitHub | Standard, free, portfolio-visible |

**No database decision:** Validated against every FR in the PRD — none require persistence across sessions. Skill benchmarks are read-only reference data, shipped as JSON in the repo.

## 2. Component Diagram

```mermaid
flowchart TB
    subgraph Client
        UI[React Frontend]
    end
    subgraph Vercel
        API[Serverless Function: /api/analyze]
        JSON[(Curated Skill Map JSON)]
    end
    subgraph Anthropic
        CLAUDE[Claude API]
    end

    UI -->|POST resume + role| API
    API -->|predefined role| JSON
    API -->|custom role: generate benchmark| CLAUDE
    API -->|resume + benchmark: analyze| CLAUDE
    CLAUDE -->|structured JSON result| API
    API -->|JSON response| UI
```

## 3. Request Lifecycle (predefined role)

```mermaid
sequenceDiagram
    participant U as User
    participant F as Frontend
    participant S as Serverless Function
    participant D as Skill Map JSON
    participant C as Claude API

    U->>F: Paste resume, select role, click Analyze
    F->>F: Validate inputs (FR-4)
    F->>S: POST /api/analyze {resumeText, role, isCustomRole:false}
    S->>D: Load skill map for role
    S->>C: Prompt: resume + skill map -> gap analysis
    C-->>S: Structured JSON (skills, gaps, roadmap, resources)
    S-->>F: 200 OK + result JSON
    F->>U: Render results dashboard
```

## 4. Request Lifecycle (custom role)

```mermaid
sequenceDiagram
    participant U as User
    participant F as Frontend
    participant S as Serverless Function
    participant C as Claude API

    U->>F: Paste resume, type custom role
    F->>S: POST /api/analyze {resumeText, role, isCustomRole:true}
    S->>C: Prompt 1: generate skill benchmark for role
    C-->>S: Benchmark JSON (must/good/bonus skills)
    S->>C: Prompt 2: resume + benchmark -> gap analysis
    C-->>S: Structured JSON result
    S-->>F: 200 OK + result JSON
    F->>U: Render results dashboard
```

## 5. Data Flow Summary

1. User input never touches AI directly — always routed through the serverless function.
2. API key lives only in Vercel environment variables, read server-side (FR-14).
3. Predefined roles skip one AI call (benchmark already curated) — faster and more consistent (PRD §5.3).
4. Custom roles cost two AI calls (benchmark + analysis) — acceptable since it's the secondary path.
5. All output is ephemeral: nothing is written to disk or a database after the response is sent.

## 6. External Services

| Service | Purpose | Failure Handling |
|---|---|---|
| Anthropic Claude API | Skill-gap generation, custom-role benchmarking | On failure/timeout, return a friendly error (FR-13); frontend shows retry option |
| Vercel | Hosting + serverless functions + env vars | N/A (platform-level) |

## 7. Error Handling Strategy

- Input validation happens client-side first (fast feedback), then server-side (defense in depth).
- AI API errors (timeout, rate limit, malformed response) are caught server-side and mapped to a generic user-facing message — raw error details are never leaked to the client.
- Malformed AI JSON output triggers a single automatic retry before failing gracefully.
