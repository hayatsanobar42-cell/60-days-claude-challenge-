# SkillPath AI — Project Structure

Version 1.0 | Day 2 Deliverable
Location within the challenge repo: `60-days-claude-challenge-/skillpath-ai/`

## 1. Full Folder Structure

```
skillpath-ai/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── InputScreen.jsx
│   │   │   ├── LoadingState.jsx
│   │   │   ├── ResultsDashboard.jsx
│   │   │   ├── SkillGapCard.jsx
│   │   │   ├── RoadmapTimeline.jsx
│   │   │   ├── ResourceList.jsx
│   │   │   └── ErrorState.jsx
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles/
│   │       └── global.css
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
│
├── api/
│   ├── analyze.js          # POST /api/analyze
│   ├── roles.js            # GET /api/roles
│   └── lib/
│       ├── claudeClient.js # wraps Anthropic API calls
│       ├── loadSkillMap.js # reads data/roles/*.json
│       └── validate.js     # shared request validation
│
├── data/
│   └── roles/
│       ├── sde.json
│       ├── data-analyst-scientist.json
│       ├── ai-ml-engineer.json
│       ├── web-developer.json
│       └── core-engineering.json
│
├── docs/
│   ├── PRD.md
│   ├── IMPLEMENTATION-BLUEPRINT.md
│   ├── PITCH-DECK.md
│   ├── ARCHITECTURE.md
│   ├── SCHEMA.md
│   ├── API.md
│   ├── UI-WIREFRAMES.md
│   └── PROJECT-STRUCTURE.md
│
├── .env.example             # documents required env vars, no real keys
├── .gitignore
├── vercel.json               # routes frontend + api together
└── README.md
```

## 2. Folder Responsibilities

| Folder/File | Responsibility |
|---|---|
| `frontend/src/components/` | One component per screen/section from UI-WIREFRAMES.md — direct 1:1 mapping keeps future code easy to locate |
| `frontend/src/App.jsx` | Owns the screen state machine (Input → Loading → Results/Error) shown in UI-WIREFRAMES.md §3 |
| `api/analyze.js`, `api/roles.js` | One file per endpoint, matching API.md exactly — no endpoint logic lives outside these two files |
| `api/lib/` | Shared logic (Claude API wrapper, validation, skill-map loading) reused by both endpoints, kept out of the endpoint files to keep them thin and readable |
| `data/roles/*.json` | Curated skill benchmarks — matches SCHEMA.md §2, one file per predefined role, read-only at runtime |
| `docs/` | All planning and design docs live together, versioned alongside the code they describe |
| `.env.example` | Documents `ANTHROPIC_API_KEY` is required, without ever committing a real key (FR-14) |
| `vercel.json` | Single config so `frontend/` and `api/` deploy together as one Vercel project |

## 3. Where Future Code Will Live

- **Day 3–4 (UI shell + mocks):** all work happens in `frontend/src/components/`, using hardcoded JSON in place of real `api/analyze.js` responses.
- **Day 5–6 (AI integration):** `api/analyze.js`, `api/roles.js`, and everything in `api/lib/` gets built out; frontend switches from mock data to real `fetch` calls.
- **Day 7 (polish):** changes stay within `frontend/src/styles/` and component markup — no structural changes expected.
- **Day 8 (testing):** no new folders; bug fixes land in existing files.
- **Day 9 (deploy):** `vercel.json` and `.env` configuration on the Vercel dashboard (not committed).

## 4. Why This Structure

- **Mirrors the architecture, not a generic template.** `frontend/` and `api/` map directly to the two runtime components in ARCHITECTURE.md's component diagram — nothing invented beyond what the system actually does.
- **No database folder.** Consistent with SCHEMA.md's finding that v1.0 needs no persistence — `data/` holds static reference JSON only.
- **Flat and shallow.** Given the 2–3 hr/day constraint, deep nesting or a monorepo tool (Nx, Turborepo) would add setup overhead with no benefit at this scale.
- **`docs/` alongside code, in the same repo folder.** Keeps the whole submission self-contained and easy for reviewers (and future-you) to navigate in one place.
