# SkillPath AI — UI & User Flow

Version 1.0 | Day 2 Deliverable
Low-fidelity wireframes — layout and intent only, no visual design system yet (that's Day 7 polish).

## 1. User Flow Diagram

```mermaid
flowchart TD
    A[Landing / Input Screen] -->|Fill resume + role| B{Valid input?}
    B -->|No| A2[Inline validation error]
    A2 --> A
    B -->|Yes| C[Loading State]
    C -->|Success| D[Results Dashboard]
    C -->|API Error| E[Error State]
    E -->|Retry| A
    D -->|Analyze another| A
```

## 2. Screens (only 3 — matches PRD's single-flow scope)

Every screen exists for exactly one reason — there is no navigation menu, no multi-page app, because the PRD defines a single linear flow (PRD §5.1).

### Screen 1: Input Screen
**Reason it exists:** collect the two required inputs (FR-1, FR-2, FR-3) and validate before submission (FR-4).

```
┌──────────────────────────────────────────────┐
│  SkillPath AI                                 │
│  Know your gap. Close it, fast.               │
│                                                │
│  Paste your resume text                       │
│  ┌──────────────────────────────────────────┐ │
│  │ [large textarea]                          │ │
│  │                                            │ │
│  └──────────────────────────────────────────┘ │
│                                                │
│  Target role                                  │
│  ┌────────────────────────┐  or type your own │
│  │ [dropdown: SDE, Data.. ▾]│  ┌─────────────┐ │
│  └────────────────────────┘  │[custom input]│ │
│                                └─────────────┘ │
│                                                │
│           [   Analyze My Skills   ]           │
│                                                │
│  (inline error text appears here if invalid)  │
└──────────────────────────────────────────────┘
```

### Screen 2: Loading State
**Reason it exists:** analysis takes ~5–15s (PRD NFR); user needs feedback that something is happening (FR-12).

```
┌──────────────────────────────────────────────┐
│                                                │
│              [ spinner / animation ]          │
│                                                │
│      Analyzing your resume against            │
│      Software Development (SDE)...            │
│                                                │
│      This usually takes 5-15 seconds          │
│                                                │
└──────────────────────────────────────────────┘
```

### Screen 3: Results Dashboard
**Reason it exists:** deliver the entire product value — skill gaps + roadmap + resources (FR-8 through FR-11).

```
┌──────────────────────────────────────────────┐
│  Results for: Software Development (SDE)      │
│  [ ← Analyze another resume ]                 │
│                                                │
│  ── Your Detected Skills ──────────────────   │
│  [Python] [SQL] [Git] [REST APIs]             │
│                                                │
│  ── Skill Gaps ────────────────────────────   │
│  🔴 Must-Have                                 │
│    • System Design Basics                     │
│      "Core screening filter for..."           │
│  🟡 Good-to-Have                              │
│    • Cloud Fundamentals (AWS/GCP)             │
│  🟢 Bonus                                     │
│    • Open Source Contribution                 │
│                                                │
│  ── Your Roadmap ──────────────────────────   │
│  Weeks 1-2 │ DSA Fundamentals                 │
│  Weeks 3-4 │ System Design Basics             │
│  Weeks 5-6 │ Cloud + Portfolio Projects       │
│                                                │
│  ── Recommended Resources ─────────────────   │
│  System Design Basics                         │
│    📘 Grokking the System Design Interview    │
│    🔗 project-idea: Design a URL shortener    │
└──────────────────────────────────────────────┘
```

### Error State (variant of Screen 1/2, not a separate screen)
**Reason it exists:** graceful handling of AI/API failure (FR-13).

```
┌──────────────────────────────────────────────┐
│   ⚠  We couldn't complete your analysis        │
│      Please try again in a moment.            │
│                                                │
│            [   Try Again   ]                  │
└──────────────────────────────────────────────┘
```

## 3. Screen Flow Summary

```mermaid
stateDiagram-v2
    [*] --> InputScreen
    InputScreen --> Loading: valid submit
    InputScreen --> InputScreen: invalid submit (inline error)
    Loading --> ResultsDashboard: success
    Loading --> ErrorState: AI/API failure
    ErrorState --> InputScreen: retry
    ResultsDashboard --> InputScreen: analyze another
    ResultsDashboard --> [*]
```

## 4. Navigation

There is **no persistent navigation bar, no routing between unrelated pages, and no menu** — by design. The entire product is one task (PRD §5.1), so the "navigation" is just the linear state machine in §3. This matches the PRD's usability goal: understandable within 10 seconds, no instructions needed.
